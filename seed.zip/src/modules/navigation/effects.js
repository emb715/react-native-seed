
const effects = {}

export default effects;
