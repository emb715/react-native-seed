import auth from './auth';
import navigation from './navigation';
import user from './user';

export default {
  auth,
  navigation,
  user,
};