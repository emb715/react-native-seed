import router from './router';
import regularUserRouter from './regularUserRouter';

export {
  router,
  regularUserRouter,
};
